package Task3;
abstract class Shape{
    abstract double area();
}
interface Printable{
    public void print();
}
class Rectangle extends Shape implements Printable{
    double width;
    double height;

    Rectangle(double width, double height){
        this.width = width;
        this.height = height;
    }
    @Override
   public double area() {
        return width * height;
    }

    @Override
    public void print() {
        System.out.println("This is a Rectangle. Area is calculated.");

    }
}
public class Task3 {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5.0, 3.0);

        double result = rect.area();
        System.out.println("Area of Rectangle: "+result);

        rect.print();

    }
}
