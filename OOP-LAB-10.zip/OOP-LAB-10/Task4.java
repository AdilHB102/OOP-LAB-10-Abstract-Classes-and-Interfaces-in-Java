package Task4;
interface Flyable{
    public void fly();
}

interface Swimmable{
    public void swim();
}
class Duck implements Flyable, Swimmable{
    @Override
    public void fly() {
        System.out.println("The Duck is Flying in the Sky.");
    }

    @Override
    public void swim() {
        System.out.println("The Duck is Swimming in the pond.");
    }
}
public class Task4 {
    public static void main(String[] args) {
        Duck myDuck = new Duck();
        myDuck.fly();
        myDuck.swim();
    }
}

