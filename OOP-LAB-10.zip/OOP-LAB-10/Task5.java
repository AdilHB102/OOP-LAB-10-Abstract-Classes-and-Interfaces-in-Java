package Task5;

abstract class Employee {
    String name;
    String id;
    Employee(String name, String id) {
        this.name = name;
        this.id = id;
    }

    abstract double calculateSalary();
}

interface TaxPayer {
    void payTax(double salary);
}

class FullTimeEmployee extends Employee implements TaxPayer {
    double monthlySalary;

    FullTimeEmployee(String name, String id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    public double calculateSalary() {
        return monthlySalary;
    }

    public void payTax(double salary) {
        double tax = salary * 0.10;
        System.out.println(name + " (Full-time) has to pay tax: Rs. " + tax);
    }
}

class PartTimeEmployee extends Employee implements TaxPayer {
    double hoursWorked;
    double ratePerHour;

    PartTimeEmployee(String name, String id, double hoursWorked, double ratePerHour) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.ratePerHour = ratePerHour;
    }

    public double calculateSalary() {
        return hoursWorked * ratePerHour;
    }

    public void payTax(double salary) {
        double tax = salary * 0.05; // 5% tax
        System.out.println(name + " (Part-time) has to pay tax: Rs. " + tax);
    }
}

public class Task5 {
    public static void main(String[] args) {
        FullTimeEmployee ft = new FullTimeEmployee("Ali", "F24101", 50000);
        double ftSalary = ft.calculateSalary();
        System.out.println("Full-time Employee Salary: Rs. " + ftSalary);
        ft.payTax(ftSalary);

        System.out.println();

        PartTimeEmployee pt = new PartTimeEmployee("Adil", "F24102", 80, 500);
        double ptSalary = pt.calculateSalary();
        System.out.println("Part-time Employee Salary: Rs. " + ptSalary);
        pt.payTax(ptSalary);
    }
}
