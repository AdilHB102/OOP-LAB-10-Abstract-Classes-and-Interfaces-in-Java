package Task2;
interface Vehicle {
    void start();
    void stop();
}

class Car implements Vehicle {
    public void start() {
        System.out.println("Car is starting with a key ignition.");
    }

    public void stop() {
        System.out.println("Car is stopping using disc brakes.");
    }
}

class Bike implements Vehicle {
    public void start() {
        System.out.println("Bike is starting.");
    }

    public void stop() {
        System.out.println("Bike is stopping using hand brakes.");
    }
}

public class Task2 {
    public static void main(String[] args) {
        Vehicle myCar = new Car();
        myCar.start();
        myCar.stop();

        Vehicle myBike = new Bike();
        myBike.start();
        myBike.stop();
    }
}
