package Task1;
abstract class Animal{
    abstract void makeSound();
    void eat(){
        System.out.println("Animal is Eating.");
    }
}
class Dog extends Animal{
    @Override
    void makeSound() {
        System.out.println("Dog is Barking.");
    }
}
class Cat extends Animal{
    @Override
    void makeSound() {
        System.out.println("Cat is Walking.");
    }
}


public class Task1 {
    public static void main(String[] args) {
        Animal dog = new Dog();
        dog.eat();
        dog.makeSound();

        Animal cat = new Cat();
        cat.eat();
        cat.makeSound();
    }
}
